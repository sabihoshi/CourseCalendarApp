﻿using TiberHealth.Serializer.Attributes;

namespace CanvasApi.Client.EnrollmentTerms.Enums
{
    [EnumAsString]
    public enum EnrollmentTermIncludes
    {
        Overrides
    }
}
