﻿using System.Collections.Generic;
using CanvasApi.Client.EnrollmentTerms.Enums;

namespace CanvasApi.Client.EnrollmentTerms.Models
{
    internal class EnrollmentTermListOptions : IEnrollmentTermListOptions
    {
        public IEnumerable<EnrollmentTermIncludes> Include { get; set; }
        public IEnumerable<EnrollmentTermListWorkflowState> WorkflowState { get; set; }
    }
}
