﻿namespace CanvasApi.Client.Accounts.Models
{
    public enum SelfRegistrationTypes
    {
        none, observer, all
    }
}
