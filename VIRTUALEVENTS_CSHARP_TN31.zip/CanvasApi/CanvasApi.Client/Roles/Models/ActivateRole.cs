﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CanvasApi.Client.Roles.Models
{
    internal class ActivateRole : IActivateRole
    {
        public int RoleId { get; set; }
    }
}
