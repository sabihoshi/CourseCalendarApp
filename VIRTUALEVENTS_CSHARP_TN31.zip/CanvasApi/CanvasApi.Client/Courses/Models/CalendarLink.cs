﻿namespace CanvasApi.Client.Courses.Models
{
    internal class CalendarLink : ICalendarLink
    {
        public string Ics { get; set; }
    }
}
