﻿using TiberHealth.Serializer.Attributes;

namespace CanvasApi.Client.Courses.Enums
{
    public enum CourseFormat
    {
        OnCampus,
        Online,
        Blended
    }
}
