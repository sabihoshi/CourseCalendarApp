﻿namespace CanvasApi.Client.Submissions.Models
{
    internal class SubmissionSubmitComment : ISubmissionSubmitComment
    {
        public string TextComment { get; set; }
    }
}
