﻿using TiberHealth.Serializer.Attributes;

namespace CanvasApi.Client.Submissions.Enums
{
    [EnumAsString]
    public enum SubmissionListOrder
    {
        Id,
        GradedAt
    }
}
