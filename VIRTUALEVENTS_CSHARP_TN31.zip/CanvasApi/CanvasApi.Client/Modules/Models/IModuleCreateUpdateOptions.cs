﻿namespace CanvasApi.Client.Modules.Models
{
    public interface IModuleCreateUpdateOptions
    {
        IModuleDetail Module { get; }
    }
}
