﻿using TiberHealth.Serializer.Attributes;

namespace CanvasApi.Client.Enrollments.Enums
{
    [EnumAsString]
    public enum EnrollmentTypes
    {
        Teacher,
        Student,
        TeacherAssistant,
        Observer,
        Designer
    }
}

