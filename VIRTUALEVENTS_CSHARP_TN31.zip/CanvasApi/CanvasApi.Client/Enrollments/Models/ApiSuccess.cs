﻿namespace CanvasApi.Client.Enrollments.Models
{
    internal class ApiSuccess : IApiSuccess
    {
        public bool? Success { get; set; }
    }
}
