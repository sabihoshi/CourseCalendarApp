﻿namespace CanvasApi.Client.Enrollments.Models
{
    public interface IApiSuccess
    {
        bool? Success { get; }
    }
}
