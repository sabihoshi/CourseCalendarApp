﻿namespace CanvasApi.Client.Pages.Enums
{
    public enum CourseGroupFlag
    {
        Course = 1,
        Group = 2
    }
}
