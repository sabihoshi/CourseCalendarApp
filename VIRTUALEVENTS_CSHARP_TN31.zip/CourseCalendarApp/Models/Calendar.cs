﻿namespace CourseCalendarApp.Models;

public class Calendar { }